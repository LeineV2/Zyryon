### Additions
- Added a option to Ignore the Class Check for the Predev Timer.
- Added a Predev Live Timer.
- Adding Predev Routes (WIP not finished).
- Added Mask Cooldown Display.
- Added a Button in the Move Guis to Toggle Text Shadow.
- Added Custom Hide Messages.
- Added Custom Storm Lightning Timer.
- Removed SS Timer. (was removed a long time ago just forgot to remove in config)

### Removals
- Removed the Coordinates Overlay.

### Fixes
- Fixed a Crash on Orange Relic Waypoint

### Changes
- Migrated to Amaterasu
- Migrated to a Custom Title instead of Client.ShowTitle()